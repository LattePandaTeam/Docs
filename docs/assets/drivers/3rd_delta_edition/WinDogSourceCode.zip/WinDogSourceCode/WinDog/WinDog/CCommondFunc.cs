﻿using System;
using System.Threading;
using System.Windows.Forms;
using System.IO;

namespace WinDog
{
    class CCommondFunc
    {
        /// <summary>
        /// Capture unhandled exceptions
        /// </summary>
        public static void StartCatchAppException()
        {
            WriteFile(FileType.RUN, "System login");
            Application.ThreadException += new ThreadExceptionEventHandler(ApplicationExceptionFunc);
        }

        /// <summary>
        /// Handle unhandled exceptions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void ApplicationExceptionFunc(object sender, ThreadExceptionEventArgs e)
        {
            string str = string.Empty;
            string strDateInfo = "Unhandled application exception occurred: " + DateTime.Now.ToString() + "\r\n";

            if (e.Exception != null)
            {
                str = string.Format(strDateInfo + "Exception Type: {0}\r\nException Message: {1}\r\nException Information: {2}\r\n",
                     e.Exception.GetType().Name, e.Exception.Message, e.Exception.StackTrace);
            }
            else
            {
                str = string.Format("Application thread error: {0}", e.Exception);
            }
            WriteFile(FileType.RUN, "Exception exit: " + str);
        }

        public enum FileType
        {
            RUN,    // Program run flag
            NET,    // Network status
            ERROR   // Error information
        }

        /// <summary>
        /// Record to a text file
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="value"></param>
        public static void WriteFile(FileType fileType, string value)
        {
            value = "[" + DateTime.Now.ToString("yyyyMMdd HH:mm:ss") + "] " + value + Environment.NewLine;

            string strPath = string.Empty;
            string strFileName = string.Empty;

            switch (fileType)
            {
                case FileType.RUN:
                    strFileName = "Run";
                    break;
                case FileType.NET:
                    strFileName = "Net";
                    break;
                case FileType.ERROR:
                    strFileName = "Error";
                    break;
                default:
                    break;
            }
            strPath = String.Format("{0}\\Log\\{1}\\", System.Windows.Forms.Application.StartupPath, strFileName);
            try
            {
                if (!Directory.Exists(strPath))
                {
                    Directory.CreateDirectory(strPath);
                }
                strPath = strPath + String.Format("{0}({1}).txt", strFileName, DateTime.Now.ToString("yyyyMM"));
                FileStream fsW = new FileStream(strPath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fsW);
                sw.WriteLine(value);
                sw.Close();
                fsW.Close();
                sw.Dispose();
                fsW.Dispose();
            }
            catch { }
        }
    }
}
