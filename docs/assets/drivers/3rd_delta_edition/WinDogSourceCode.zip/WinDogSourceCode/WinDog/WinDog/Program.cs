﻿using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using static WinDog.CCommondFunc;
using Microsoft.Win32.TaskScheduler;
using Microsoft.Win32;
using System.Diagnostics.Eventing.Reader;

namespace WinDog
{
    class Program
    {
        static WinIoPort io = new WinIoPort();
        static NotifyIcon notifyIcon;
        static bool exitThread = false; // Flag to indicate whether the background monitoring thread should exit
        static MenuItem menuItemNewOption;
        static ContextMenu contextMenu;
        [STAThread]
        static void Main(string[] args)
        {
            bool runOne = false;

            // Set up application settings
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            SystemEvents.SessionEnding += SystemEvents_SessionEnding;


            // Run the application using Mutex to ensure single instance
            System.Threading.Mutex run = new System.Threading.Mutex(true, "WinDog", out runOne);
            if (!runOne) return;

            // Get the current directory
            string currentDirectory = Directory.GetCurrentDirectory();
            Console.WriteLine("Current Directory: " + currentDirectory);

            // Configure auto-start with Windows
            AutoStart("lattepanda_autodog", currentDirectory + "\\WinDog.exe", "auto");

            // Initialize I/O port
            io.Init();

            // Start the background monitoring thread
            ThreadStart childRef = new ThreadStart(CallToChildThread);
            Console.WriteLine("In Main: Creating the Child thread");
            Thread childThread = new Thread(childRef);
            childThread.Start();

            // Prevent the following code from executing after Application.Run(), as it is a blocking operation
            Application.Run();
        }

        // Super I/O port entry configuration
        static void superio_enter()
        {
            io.SetValue(0x2E, 0x87);
            io.SetValue(0x2E, 0x01);
            io.SetValue(0x2E, 0x55);
            io.SetValue(0x2E, 0x55);
        }
        private static void SystemEvents_SessionEnding(object sender, SessionEndingEventArgs e)
        {
            Console.WriteLine("User is logging out of the system....");
            WriteFile(FileType.RUN, "User is logging out of the system.! \n");

            superio_enter();
            io.SetValue(0x2E, 0x07);
            io.SetValue(0x2F, 0x07);

            io.SetValue(0x2E, 0x72);
            io.SetValue(0x2F, 0x80);
            superio_exit();
            Environment.Exit(0);
            // 
        }
        // Read from the specified register in the Super I/O port
        static UInt32 superio_inb(byte reg)
        {
            UInt32 val;
            io.SetValue(0x2E, reg);

            val = io.GetValue(0x2F);
            return val;
        }

        // Super I/O port exit configuration
        static void superio_exit()
        {
            io.SetValue(0x2E, 0x02);
            io.SetValue(0x2F, 0x02);
        }

        // Feed the watchdog with the specified value
        static void feed_dog(byte val)
        {
            io.SetValue(0x2E, 0x73);
            io.SetValue(0x2F, (byte)val);
            val = (byte)(val >> 8);
            if (val > 255)
            {
                io.SetValue(0x2E, 0x74);
                io.SetValue(0x2F, val);
            }
        }

        // Background monitoring thread logic
        private static void CallToChildThread()
        {
            // Read the chip ID of the super I/O
            superio_enter();
            Console.WriteLine("Chip Type: {0}{1}", superio_inb(0x20), superio_inb(0x21));
            WriteFile(FileType.RUN, "Exception Exit:{0}{1}" + superio_inb(0x20) + superio_inb(0x21));
            superio_exit();

            // Configure the super I/O chip
            superio_enter();
            io.SetValue(0x2E, 0x07);
            io.SetValue(0x2F, 0x07);

            io.SetValue(0x2E, 0x72);
            io.SetValue(0x2F, 0x90);
            io.SetValue(0x2E, 0x73);
            io.SetValue(0x2F, 0x3C);
            io.SetValue(0x2E, 0x74);
            io.SetValue(0x2F, 0x00);
            superio_exit();

            while (!exitThread)
            {
                // Feed the watchdog
                superio_enter();
                io.SetValue(0x2E, 0x07);
                io.SetValue(0x2F, 0x07);
                feed_dog(60);
                Console.WriteLine("Finished! \n");
               // WriteFile(FileType.RUN, "Finished! \n");
                superio_exit();
                Thread.Sleep(30000); // Update every 30 seconds
            }
        }

        // Event handler for double-clicking the icon
        private static void NotifyIcon_DoubleClick(object sender, EventArgs e)
        {
            // Operation to be performed on double-clicking the icon
            // MessageBox.Show("Icon double-clicked!");
        }

        // Event handler for clicking "Exit" menu
        private static void MenuItemExit_Click(object sender, EventArgs e)
        {
            // Operation to be performed on clicking "Exit" menu
            exitThread = true; // Set the flag to notify the background monitoring thread to exit
            notifyIcon.Visible = false;

            superio_enter();
            io.SetValue(0x2E, 0x07);
            io.SetValue(0x2F, 0x07);

            io.SetValue(0x2E, 0x72);
            io.SetValue(0x2F, 0x80);
            superio_exit();

            Application.Exit();
            Environment.Exit(0);

        }
        public static void RemoveFromStartup(string taskName)
        {
            if (string.IsNullOrEmpty(taskName))
            {
                throw new ArgumentNullException();
            }

            using (var taskService = new TaskService())
            {
                // 
                var existingTask = taskService.GetTask(taskName);

                if (existingTask != null)
                {
                    // 
                    taskService.RootFolder.DeleteTask(taskName, false);
                    Console.WriteLine("Successfully removed from startup! \n");
                }
                else
                {
                    // 
                    Console.WriteLine($"Task '{taskName}' does not exist. No need to remove from startup.");
                }
            }
        }
        private static void MenuItemNewOption_Click(object sender, EventArgs e) {

            var logonUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;



            string TaskName = "lattepanda_autodog";
            string taskDescription = "auto";
            string currentDirectory = Directory.GetCurrentDirectory();
            string deamonFileName = currentDirectory + "\\WinDog.exe";

            using (var taskService = new TaskService())
            {
                // Check if a task with the same name already exists
                var existingTask = taskService.GetTask(TaskName);

                if (existingTask == null)
                {


                    // If the task doesn't exist, prompt the user to add the task
                    var result = MessageBox.Show("Do you want to add the application to startup?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        // User chooses "Yes", perform the task addition operation
                        var task = taskService.NewTask();
                        task.RegistrationInfo.Description = taskDescription;
                        task.Settings.DisallowStartIfOnBatteries = false;
                        task.Triggers.Add(new LogonTrigger { UserId = logonUser });
                        task.Principal.RunLevel = TaskRunLevel.Highest;
                        task.Actions.Add(new ExecAction(deamonFileName));
                        Console.WriteLine("AutoStart! \n");
                        MessageBox.Show("Application successfully added to startup!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        taskService.RootFolder.RegisterTaskDefinition(TaskName, task);
                        menuItemNewOption.Text = "Remove from Startup";
                    }
                    else
                    {

                        Console.WriteLine("User chose not to add the task.");
                    }
                    



                }
                else {
                    // If the task doesn't exist, prompt the user to add the task
                    var result = MessageBox.Show("Do you want to remove the application from startup?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        RemoveFromStartup(TaskName);
                        MessageBox.Show("Application successfully remove from startup!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        menuItemNewOption.Text = "Add to Startup";
                    }
                    else {
                        Console.WriteLine("User chose not to remove the task.");
                    }

                    

                }

            }

        }

        // AutoStart function to configure application startup with Windows
        public static void AutoStart(string taskName, string fileName, string description)
        {
            // Source file path
            string sourceFilePath = "stopwatch.ico";

            // Destination file path
            string destinationFilePath = "C:\\Windows\\System32\\stopwatch.ico";

            try
            {
                // Copy the file
                File.Copy(sourceFilePath, destinationFilePath, true);
                Console.WriteLine("File copied successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"File copy failed: {ex.Message}");
            }

            if (string.IsNullOrEmpty(taskName) || string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentNullException();
            }


            // Create NotifyIcon instance
            notifyIcon = new NotifyIcon();
            notifyIcon.Icon = new System.Drawing.Icon("./stopwatch.ico"); // Set icon path
            notifyIcon.Visible = true;

            // Add context menu
            contextMenu = new ContextMenu();
            MenuItem menuItemExit = new MenuItem("stop&&exit");
            menuItemExit.Click += MenuItemExit_Click;
            contextMenu.MenuItems.Add(menuItemExit);


            var logonUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            string TaskName = taskName;
            string taskDescription = description;
            string deamonFileName = fileName;

            using (var taskService = new TaskService())
            {
                // Check if a task with the same name already exists
                var existingTask = taskService.GetTask(TaskName);

                if (existingTask == null)
                {


                    menuItemNewOption = new MenuItem("Add to Startup");
                    menuItemNewOption.Click += MenuItemNewOption_Click;  // 

                    // 
                    contextMenu.MenuItems.Add(menuItemNewOption);

                }
                else
                {
                    menuItemNewOption = new MenuItem("Remove from Startup");
                    menuItemNewOption.Click += MenuItemNewOption_Click;  // 

                    // 
                    contextMenu.MenuItems.Add(menuItemNewOption);
                }

                notifyIcon.ContextMenu = contextMenu;
                notifyIcon.Text = "WinDog v0.0.3";
                // Handle double-click on the icon
                notifyIcon.DoubleClick += NotifyIcon_DoubleClick;
            }

        }
    }
}
