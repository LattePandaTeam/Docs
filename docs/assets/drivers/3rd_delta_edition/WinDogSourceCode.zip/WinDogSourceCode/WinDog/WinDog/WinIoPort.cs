﻿using System;
using System.Runtime.InteropServices;

namespace WinDog
{
    class WinIoPort
    {
        [DllImport("kernel32.dll")]
        private extern static IntPtr LoadLibrary(String DllName);

        [DllImport("kernel32.dll")]
        private extern static IntPtr GetProcAddress(IntPtr hModule, String ProcName);

        [DllImport("kernel32")]
        private extern static bool FreeLibrary(IntPtr hModule);

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate bool InitializeWinIoType();

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private unsafe delegate bool GetPortValType(UInt16 PortAddr, UInt32* pPortVal, UInt16 Size);

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate bool SetPortValType(UInt16 PortAddr, UInt32 PortVal, UInt16 Size);

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate bool ShutdownWinIoType();

        IntPtr hMod;

        public void Init()
        {
            // Check if this is a 32 bit or 64 bit system
            if (IntPtr.Size == 4)
            {
                hMod = LoadLibrary("WinIo32.dll");
                Console.WriteLine("32!");

            }
            else if (IntPtr.Size == 8)
            {
                hMod = LoadLibrary("WinIo64.dll");
                Console.WriteLine("64!");
            }

            if (hMod == IntPtr.Zero)
            {
                CCommondFunc.WriteFile(WinDog.CCommondFunc.FileType.RUN, "Message at LoadLibrary: Can't find WinIo dll.");
            }

            IntPtr pFunc = GetProcAddress(hMod, "InitializeWinIo");

            if (pFunc != IntPtr.Zero)
            {
                InitializeWinIoType InitializeWinIo = (InitializeWinIoType)Marshal.GetDelegateForFunctionPointer(pFunc, typeof(InitializeWinIoType));
                
                
                
                bool Result = InitializeWinIo();

                if (!Result)
                {

                    Console.WriteLine("error false");
                    CCommondFunc.WriteFile(WinDog.CCommondFunc.FileType.RUN, "Message at InitializeWinIo: Make sure you are running with administrative privileges and that the WinIo library files are located in the same directory as your executable file.");
                    FreeLibrary(hMod);
                }
                else
                {
                      CCommondFunc.WriteFile(WinDog.CCommondFunc.FileType.RUN, "Message at InitializeWinIo: Make true ");
                      Console.WriteLine("true");
                }
                }
        }

        public UInt32 GetValue(byte binaryAddress)
        {
            IntPtr pFunc = GetProcAddress(hMod, "GetPortVal");

            if (pFunc != IntPtr.Zero)
            {
                UInt16 PortAddr = binaryAddress;//UInt16.Parse(txtPortAddr.Text, System.Globalization.NumberStyles.HexNumber);
                unsafe
                {
                    UInt32 PortVal;

                    GetPortValType GetPortVal = (GetPortValType)Marshal.GetDelegateForFunctionPointer(pFunc, typeof(GetPortValType));

                    // Call WinIo to get value
                    bool Result = GetPortVal(PortAddr, &PortVal, 1);

                    if (!Result)
                    {
                        CCommondFunc.WriteFile(WinDog.CCommondFunc.FileType.RUN, "Message at GetPortVal");
                    }

                    return PortVal;
                }
                
            }
            return 0;
        }

        public void SetValue(byte binaryAddress, byte binaryValue)
        {
            IntPtr pFunc = GetProcAddress(hMod, "SetPortVal");
      
            if (pFunc != IntPtr.Zero)
            {
                UInt16 PortAddr;
                UInt32 PortVal;

                PortAddr = binaryAddress;//UInt16.Parse(txtPortAddr.Text, System.Globalization.NumberStyles.HexNumber);
                PortVal = binaryValue;//UInt32.Parse(txtValue.Text, System.Globalization.NumberStyles.HexNumber);

                SetPortValType SetPortVal = (SetPortValType)Marshal.GetDelegateForFunctionPointer(pFunc, typeof(SetPortValType));

                // Call WinIo to set value
                bool Result = SetPortVal(PortAddr, PortVal, 1);

                if (!Result)
                {
                    Console.WriteLine("set error");
                    CCommondFunc.WriteFile(WinDog.CCommondFunc.FileType.RUN, "Message at SetPortVal");
                }
                else {
                   // Console.WriteLine("set sucess");
                }
            }
        }
    }
}
