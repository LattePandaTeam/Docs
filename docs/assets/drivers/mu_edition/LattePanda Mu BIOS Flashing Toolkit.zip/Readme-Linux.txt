1. Copy the BIOS firmware (.bin file) to this directory

2. Add execution permissions to FPT
`chmod +x ./FPT`

3. Execute the BIOS upgrade
`./FPT -f <BIOS_File>`