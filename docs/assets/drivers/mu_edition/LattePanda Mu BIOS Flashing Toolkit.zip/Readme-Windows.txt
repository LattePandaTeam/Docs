1. Copy the BIOS firmware (.bin file) to this directory.

2. Run UPDATE.BAT as an administrator.