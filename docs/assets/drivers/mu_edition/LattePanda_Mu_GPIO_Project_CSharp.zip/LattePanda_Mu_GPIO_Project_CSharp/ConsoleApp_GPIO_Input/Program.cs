﻿/*!
 * @file Program.cs
 * @brief GPIO level monitor demo for LattePanda Mu using Windows.Devices.Gpio (WinRT API).
 * @Hardware LattePanda Mu (Intel N100/N305)
 * @BIOS S70NC1R200-8G-B or later
 * @author LattePanda Team(https://www.lattepanda.com/)
 * @version V1.0
 * @date 2026-06
 * @license The MIT License (MIT)
 */

using Windows.Devices.Gpio;

// LattePanda Mu(N100/N305): physical GPIO name to WinRT logical GPIO index mapping.
var PinMapping = new Dictionary<string, int>
{
    { "GPP_A12",  0 },
    { "GPP_E0",   1 },
    { "GPP_D0",   2 },
    { "GPP_D1",   3 },
    { "GPP_D2",   4 },
    { "GPP_D3",   5 },
    { "GPP_F12",  6 },
    { "GPP_F13",  7 },
    { "GPP_F14",  8 },
    { "GPP_F15",  9 },
    { "GPP_F16", 10 },
    { "GPP_H10", 11 },   // SOC_UART0_RXD - avoid using as GPIO when UART is active.
    { "GPP_H11", 12 },   // SOC_UART0_TXD
    { "GPP_D17", 13 },   // SOC_UART1_RXD
    { "GPP_D18", 14 },   // SOC_UART1_TXD
    { "GPP_F1",  15 },   // SOC_UART2_RXD
    { "GPP_F2",  16 },   // SOC_UART2_TXD
};

// Target pin to monitor. Change this string to switch to a different pin.
const string TargetPin = "GPP_F12";
const int IntervalMs = 1000;    // Polling interval in milliseconds

// Resolve the WinRT GPIO index for the selected pad
if (!PinMapping.TryGetValue(TargetPin, out int PinNumber))
{
    Console.WriteLine($"Unknown Pin name: {TargetPin}. Check the mapping table.");
    Console.WriteLine("Press Enter to exit.");
    Console.ReadLine();
    return;
}

bool stopRequested = false;
// Register Ctrl+C handler so the user can terminate the monitor loop cleanly
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;        // Prevent immediate process termination
    stopRequested = true;
    Console.WriteLine("Ctrl+C detected, exiting...");
};

Console.WriteLine($"GPIO input monitor started. Pin: {TargetPin}, Mapping Number: {PinNumber}, interval: {IntervalMs}ms, mode: hardware.");

// Obtain the default WinRT GPIO controller.
// Returns null if the GPIO driver is not loaded or BIOS pin mux is not configured.
GpioController? controller = GpioController.GetDefault();
if (controller is null)
{
    Console.WriteLine("WinRT GPIO controller is unavailable. Check BIOS pin mux and driver/capability settings.");
    Console.WriteLine("Press Enter to exit.");
    Console.ReadLine();
    return;
}

// Open the target pin and configure it as a floating input.
using GpioPin pin = controller.OpenPin(PinNumber);
pin.SetDriveMode(GpioPinDriveMode.Input);

Console.WriteLine("Monitoring pin level. Press Ctrl+C to exit.");

// Poll the pin level at the configured interval and print the current state.
while (!stopRequested)
{
    GpioPinValue value = pin.Read();
    Console.WriteLine($"{DateTime.Now:HH:mm:ss} {TargetPin} (Mapping Number:{PinNumber}) -> {value}");

    if (!stopRequested)
    {
        Thread.Sleep(IntervalMs);
    }
}