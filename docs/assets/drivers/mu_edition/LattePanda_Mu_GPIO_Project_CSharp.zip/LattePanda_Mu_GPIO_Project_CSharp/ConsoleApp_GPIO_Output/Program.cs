﻿/*!
 * @file Program.cs
 * @brief GPIO toggle demo for LattePanda Mu using Windows.Devices.Gpio (WinRT API).
 * @Hardware LattePanda Mu (Intel N100/N305)
 * @BIOS S70NC1R200-8G-B or later
 * @author LattePanda Team(https://www.lattepanda.com/)
 * @version V1.0
 * @date 2026-06
 * @license The MIT License (MIT)
 */

using Windows.Devices.Gpio;

// LattePanda Mu(N100/N305): physical GPIO name to WinRT logical GPIO index mapping.
var PinMapping = new Dictionary<string, int>()
{
    { "GPP_A12",  0 },
    { "GPP_E0",   1 },
    { "GPP_D0",   2 },
    { "GPP_D1",   3 },
    { "GPP_D2",   4 },
    { "GPP_D3",   5 },
    { "GPP_F12",  6 },
    { "GPP_F13",  7 },
    { "GPP_F14",  8 },
    { "GPP_F15",  9 },
    { "GPP_F16", 10 },
    { "GPP_H10", 11 },   // SOC_UART0_RXD - avoid using as GPIO when UART is active.
    { "GPP_H11", 12 },   // SOC_UART0_TXD
    { "GPP_D17", 13 },   // SOC_UART1_RXD
    { "GPP_D18", 14 },   // SOC_UART1_TXD
    { "GPP_F1",  15 },   // SOC_UART2_RXD
    { "GPP_F2",  16 },   // SOC_UART2_TXD
};

// Select the target pin by name. Change "GPP_F12" to any key in PinMapping above.
const string TargetPin = "GPP_F12";
int PinNumber = PinMapping[TargetPin];

// Toggle interval in milliseconds — the pin state flips once per period.
const int IntervalMs = 1000;

// Flag set by the Ctrl+C handler to break the toggle loop.
bool stopRequested = false;

// Handle Ctrl+C gracefully: cancel the default termination so the finally-path (pin drive low) can execute before the program exits.
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    stopRequested = true;
    Console.WriteLine("Ctrl+C detected, exiting...");
};

Console.WriteLine($"GPIO output toggling started. Pin: {TargetPin}, Mapping Number: {PinNumber}, interval: {IntervalMs}ms, mode:hardware.");

// Obtain the default WinRT GPIO controller.
// Returns null if no controller is available (driver not loaded or BIOS disabled).
GpioController? controller = GpioController.GetDefault();
if (controller is null)
{
    Console.WriteLine("WinRT GPIO controller is unavailable. Check BIOS pin mux and driver/capability settings.");
    return;
}

// Open the target pin and configure it as a push-pull output.
// The pin is held open for the lifetime of the toggle loop via the using statement.
using GpioPin pin = controller.OpenPin(PinNumber);
pin.SetDriveMode(GpioPinDriveMode.Output);                  // Set pin mode to output
pin.Write(GpioPinValue.Low);                                // Set initial value to Low

// Toggle loop: flip the pin state every IntervalMs milliseconds until Ctrl+C.
GpioPinValue currentValue = GpioPinValue.Low;
while (!stopRequested)
{
    // Invert the current pin level.
    currentValue = (currentValue == GpioPinValue.Low) ? GpioPinValue.High : GpioPinValue.Low;

    pin.Write(currentValue);
    Console.WriteLine($"{DateTime.Now:HH:mm:ss} {TargetPin} (Mapping Number:{PinNumber}) -> {currentValue}");

    if (!stopRequested)
    {
        Thread.Sleep(IntervalMs);
    }
}

// Release the pin by switching to input (high-impedance), relinquishing drive control
pin.SetDriveMode(GpioPinDriveMode.Input);