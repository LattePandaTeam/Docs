﻿/*!
 * @file Program.cs
 * @brief Single-byte EEPROM read/write demo via WinRT I2C API.
 * @target AT24C256 (256 Kbit / 32 KB, 16-bit memory address, I2C address 0x50–0x57)
 * @Hardware LattePanda Mu (Intel N100/N305); AT24C256 EEPROM Module(DFR0117)
 * @BIOS S70NC1R200-8G-B or later
 * @author LattePanda Team(https://www.lattepanda.com/)
 * @version V1.0
 * @date 2026-06
 * @license The MIT License (MIT)
 */

using Windows.Devices.Enumeration;
using Windows.Devices.I2c;

// Available in I2C2, I2C3, I2C4, I2C5
const string BusName = "I2C2";

// AT24C256 base I2C address (A2=A1=A0=GND → 0x50).
const int AT24CXXAddress = 0x50;

// Ctrl+C handler — set a flag so the main loop exits cleanly.
bool stopRequested = false;
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;        // Suppress default process termination; let the loop exit gracefully.
    stopRequested = true;
    Console.WriteLine("Ctrl+C detected, exiting...");
};

Console.WriteLine($"Single-byte EEPROM read/write started. bus={BusName}, addr=0x{AT24CXXAddress:X2}, mem=0x0000, mode=hardware.");

// Discover WinRT I2C controllers registered on the requested bus.
// FindAllAsync queries the PnP device tree; an empty result means the driver is absent or the bus is disabled in BIOS / ACPI tables.
DeviceInformationCollection controllers =
    await DeviceInformation.FindAllAsync(I2cDevice.GetDeviceSelector(BusName));

if (controllers.Count == 0)
{
    Console.WriteLine(
        "No WinRT I2C controller found. " +
        "Check BIOS I2C enable/pin mux settings.");
    return;
}


// Open the target I2C device.
// Exclusive mode is required for an EEPROM: it ensures the driver performs a real START + address + STOP on the bus, 
// and prevents address conflicts with other handles that might accidentally open the same device simultaneously.
var settings = new I2cConnectionSettings(AT24CXXAddress)
{
    BusSpeed    = I2cBusSpeed.StandardMode,
    SharingMode = I2cSharingMode.Exclusive  // Must be Exclusive for a real EEPROM device.
};

I2cDevice? device = await I2cDevice.FromIdAsync(controllers[0].Id, settings);
if (device is null)
{
    // FromIdAsync returns null when the address is already opened in Exclusive mode by another process, 
    // or when the driver rejects the open request.
    Console.WriteLine($"WinRT I2C open failed. addr=0x{AT24CXXAddress:X2}");
    return;
}

// Main loop — write then read back one byte at memory address 0x0000.
using (device)
{
    try
    {
        byte dataToWrite = 0xA5; // Test pattern: write 0xA5 to verify read-back

        // Write one byte to address 0x0000, then wait for AT24C256 internal write cycle to complete 
        // (tWR max 5 ms; 10 ms gives safe margin)
        WriteOneByte(device, 0x0000, dataToWrite);
        await Task.Delay(10);

        byte readValue = ReadOneByte(device, 0x0000);
        string match = (readValue == dataToWrite) ? "OK" : "MISMATCH";
        Console.WriteLine($"{DateTime.Now:HH:mm:ss} Write=0x{dataToWrite:X2}, Read=0x{readValue:X2} [{match}]");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"{DateTime.Now:HH:mm:ss} I2C transaction error: {ex.GetType().Name} - {ex.Message}");
    }
}

// Single read/write completed. Block here until user presses Ctrl+C.
Console.WriteLine("Done. Press Ctrl+C to exit.");
while (!stopRequested)
{
    Thread.Sleep(100);
}

// ---------------------------------------------------------------------------
// WriteOneByte — perform a random write to a 16-bit memory address.
//
// AT24C256 write frame (3 bytes total):
//   [0] MSB of 15-bit memory address  (A14–A8)
//   [1] LSB of memory address          (A7–A0)
//   [2] Data byte
//
// The EEPROM latches the data into its internal page buffer and then starts
// the self-timed write cycle (tWR). Do NOT issue another write before tWR expires.
// ---------------------------------------------------------------------------
static void WriteOneByte(I2cDevice device, ushort address, byte data)
{
    byte[] writeBuffer =
    [
        (byte)(address >> 8),   // Memory address high byte
        (byte)(address & 0xFF), // Memory address low byte
        data                    // Data to write
    ];
    device.Write(writeBuffer);
}

// ---------------------------------------------------------------------------
// ReadOneByte — perform a random read from a 16-bit memory address.
//
// This is a combined WriteRead (repeated-START) transaction:
//   Write phase : send the 16-bit memory address (sets the internal address pointer).
//   Read phase  : clock out 1 byte; EEPROM auto-increments the pointer after each byte.
// ---------------------------------------------------------------------------
static byte ReadOneByte(I2cDevice device, ushort address)
{
    byte[] addressBuffer =
    [
        (byte)(address >> 8),   // Memory address high byte
        (byte)(address & 0xFF)  // Memory address low byte
    ];
    byte[] readBuffer = new byte[1];

    // WriteRead issues a repeated START between the write and read phases,
    // which is required by the AT24C256 random read protocol.
    device.WriteRead(addressBuffer, readBuffer);

    return readBuffer[0];
}