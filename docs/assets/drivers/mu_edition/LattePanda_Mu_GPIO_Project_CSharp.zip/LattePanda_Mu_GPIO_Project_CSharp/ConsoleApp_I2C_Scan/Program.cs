﻿/*!
 * @file Program.cs
 * @brief I2C bus scanner for LattePanda Mu using Windows.Devices.I2c (WinRT API).
 *        Probes each address in the valid 7-bit range and reports responding devices.
 * @Hardware LattePanda Mu (Intel N100/N305); I2C device
 * @BIOS S70NC1R200-8G-B or later
 * @author LattePanda Team(https://www.lattepanda.com/)
 * @version V1.0
 * @date 2026-06
 * @license The MIT License (MIT)
 */

using Windows.Devices.Enumeration;
using Windows.Devices.I2c;

// available in I2C2, I2C3, I2C4, I2C5
const string BusName = "I2C2";

// Valid 7-bit I2C address range: 0x03–0x77.
// Addresses 0x00–0x02 and 0x78–0x7F are reserved by the I2C specification and should never be probed to avoid unintended bus side-effects.
const int FirstAddress = 0x03;
const int LastAddress  = 0x77;

// Windows.Devices.I2c requires Windows 10 version 1809 (build 17763) or later. Earlier builds lack the necessary WinRT I2C inbox driver support.
Version minimumWindowsVersion = new(10, 0, 17763, 0);

try
{
    EnsureSupportedWindows(minimumWindowsVersion);
    await RunScanAsync();
}
catch (Exception ex)
{
    Console.WriteLine($"Fatal error: {ex.GetType().Name} - {ex.Message}");
    // Use Enter-to-exit strategy here because Ctrl+C handler is not yet registered at the point this catch block may be reached (e.g., version check failure).
    WaitForExitIfInteractive();
    Environment.ExitCode = -1;
}

async Task RunScanAsync()
{
    bool stopRequested = false;

    // Register Ctrl+C handler before starting any blocking work so the user can always abort cleanly. e.Cancel = true prevents the OS from killing the process immediately, 
    // giving us a chance to finish the current iteration gracefully.
    Console.CancelKeyPress += (_, e) =>
    {
        e.Cancel = true;
        stopRequested = true;
        Console.WriteLine("Ctrl+C detected, exiting...");
    };

    Console.WriteLine($"I2C scan started. preferredBus={BusName}, range=0x{FirstAddress:X2}-0x{LastAddress:X2}, mode=hardware.");

    // FindAllAsync with the device selector returned by GetDeviceSelector() queries the WinRT device enumeration layer for all I2C controllers that match the requested bus name.
    // Each controller (I2C2–I2C5) appears as a separate DeviceInformation entry.
    DeviceInformationCollection devices = await DeviceInformation.FindAllAsync(
        I2cDevice.GetDeviceSelector(BusName));

    if (devices.Count == 0)
    {
        Console.WriteLine("No WinRT I2C controller found. Check BIOS I2C enable/pin mux settings and WinRT I2C driver state.");
        WaitForExitIfInteractive();
        return;
    }

    // Use the first enumerated controller that matches BusName. In practice, GetDeviceSelector(BusName) returns at most one matching entry.
    string deviceId = devices[0].Id;

    var foundAddresses = new List<int>();
    Exception? firstError = null;  // Capture the first probe error for diagnostic output.

    for (int address = FirstAddress; address <= LastAddress; address++)
    {
        try
        {
            var settings = new I2cConnectionSettings(address)
            {
                // StandardMode = 100 kHz. Use FastMode (400 kHz) only if all devices on the bus are confirmed to support it.
                BusSpeed = I2cBusSpeed.StandardMode,

                // Exclusive mode: the driver issues a real START+address+STOP on the bus and throws an exception when the address is NACKed.
                // This is the correct mode for scanning — Shared mode may succeed even for non-existent addresses and produce false positives.
                SharingMode = I2cSharingMode.Exclusive
            };

            // FromIdAsync opens a logical handle to the device at 'address'.
            // Returns null if the driver cannot satisfy the request for reasons other than a missing ACK (e.g., resource conflict).
            using I2cDevice? probe = await I2cDevice.FromIdAsync(deviceId, settings);
            if (probe is null)
            {
                continue;
            }

            // Perform a 1-byte read to confirm the device responds with an ACK.
            // The content of the byte is irrelevant; we only care whether the transaction succeeds (ACK) or throws (NACK / bus error).
            byte[] readBuffer = new byte[1];
            probe.Read(readBuffer);
            foundAddresses.Add(address);
        }
        catch (Exception ex)
        {
            // A NACK or bus error means no device at this address — expected during a scan. 
            // Record only the first error to surface unexpected failures(e.g., bus locked up, driver fault) in the summary output.
            firstError ??= ex;
        }
    }

    // Report results with a timestamp for log readability.
    string timestamp = DateTime.Now.ToString("HH:mm:ss");
    if (foundAddresses.Count == 0)
    {
        if (firstError is null)
        {
            Console.WriteLine($"{timestamp} No device found.");
        }
        else
        {
            // firstError gives a hint when every probe failed abnormally rather than via a clean NACK (e.g., driver timeout, access denied).
            Console.WriteLine($"{timestamp} No device found. Probe error: {firstError.GetType().Name} - {firstError.Message}");
        }
    }
    else
    {
        string addresses = string.Join(", ", foundAddresses.Select(addr => $"0x{addr:X2}"));
        Console.WriteLine($"{timestamp} Found: {addresses}");
    }

    // Spin-wait until the user presses Ctrl+C.
    // 100ms sleep keeps CPU usage negligible while still feeling responsive.
    Console.WriteLine("Scan completed. Press Ctrl+C to exit.");
    while (!stopRequested)
    {
        Thread.Sleep(100);
    }
}

// Verify the host OS is Windows and meets the minimum build requirement before attempting any WinRT API calls, which would throw cryptic COMExceptions otherwise.
void EnsureSupportedWindows(Version minimumVersion)
{
    if (!OperatingSystem.IsWindows())
    {
        throw new PlatformNotSupportedException("This sample only supports Windows.");
    }

    Version currentVersion = Environment.OSVersion.Version;
    if (currentVersion < minimumVersion)
    {
        throw new PlatformNotSupportedException(
            $"Windows version {currentVersion} is lower than required {minimumVersion}.");
    }
}

// Prevent the console window from closing immediately when the program is launched by double-clicking the exe (non-redirected interactive session).
// Skipped when stdout/stdin is redirected (CI pipelines, shell scripts) to avoid blocking automated runs waiting for input that never comes.
void WaitForExitIfInteractive()
{
    if (Console.IsInputRedirected || Console.IsOutputRedirected)
    {
        return;
    }

    Console.WriteLine("Press Enter to exit.");
    _ = Console.ReadLine();
}