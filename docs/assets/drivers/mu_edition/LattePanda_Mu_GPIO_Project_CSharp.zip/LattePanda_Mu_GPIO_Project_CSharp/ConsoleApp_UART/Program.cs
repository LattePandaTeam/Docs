﻿/*!
 * @file Program.cs
 * @hardware LattePanda Mu (Intel N100/N305)
 * @BIOS S70NC1R200-8G-A or later
 * @author LattePanda Team(https://www.lattepanda.com/)
 * @version V1.0
 * @date 2026-06
 * @license The MIT License (MIT)
 * @brief Serial loopback sample code. Short-circuit the TX and RX pins of the corresponding serial port before running this program.
 */

using System;
using System.IO.Ports;
using System.Text;
using System.Threading;

class Program
{
    const string COM_PORT  = "COM1";   // Windows COM port(COM1: SIO_UART)

    const int    BAUD_RATE = 9600;

    static void Main(string[] args)
    {
        // ----------------------------------------------------------------
        // Graceful exit support for double-click launched executables.
        // Without this, the console window disappears immediately after the program finishes, giving the user no time to read the output.
        // ManualResetEventSlim is a lightweight synchronisation primitive that blocks until Set() is called from the Ctrl+C handler.
        // ----------------------------------------------------------------
        var exitEvent = new ManualResetEventSlim(false);
        Console.CancelKeyPress += (sender, e) =>
        {
            e.Cancel = true;          // Prevent the process from terminating immediately
            exitEvent.Set();          // Signal the main thread to proceed with cleanup
        };

        // Declare outside try so the finally block can always reach it.
        SerialPort? ser = null;

        try
        {
            ser = new SerialPort(
                portName : COM_PORT,
                baudRate : BAUD_RATE,
                parity   : Parity.None,   // No parity bit
                dataBits : 8,             // 8 data bits per frame
                stopBits : StopBits.One   // 1 stop bit
            );

            // Timeout values (ms) prevent indefinite blocking if the loopback wire is missing or the UART is unresponsive.
            ser.ReadTimeout  = 1000;  // Throw TimeoutException after 1s with no incoming data
            ser.WriteTimeout = 1000;  // Throw TimeoutException after 1s if TX buffer is full

            // Open the port — allocates the OS handle and configures the hardware UART.
            ser.Open();
            Console.WriteLine($"Serial port opened: {ser.PortName}");

            // ----------------------------------------------------------------
            // Transmit phase
            // Convert the string to a raw byte array before writing;
            // SerialPort.Write() operates on bytes, not characters.
            // ----------------------------------------------------------------
            string txString = $"Hello from C# {ser.PortName},{ser.BaudRate}\r\n";
            byte[] txData   = Encoding.ASCII.GetBytes(txString);
            ser.Write(txData, 0, txData.Length);  // offset=0, send all bytes
            Console.WriteLine($"Sent: {txString.TrimEnd()}");

            // Give the UART hardware time to echo the bytes back through the loopback wire before we attempt to read.
            Thread.Sleep(500);

            Console.WriteLine("Waiting for data...");

            // ----------------------------------------------------------------
            // Receive phase
            // Allocate a receive buffer large enough for the expected payload.
            // ser.Read() returns the actual number of bytes read, which may be less than the buffer size.
            // ----------------------------------------------------------------
            byte[] rxData    = new byte[128];
            int    bytesRead = 0;

            try
            {
                // Blocking read — waits up to ReadTimeout ms for incoming data.
                bytesRead = ser.Read(rxData, 0, rxData.Length);
            }
            catch (TimeoutException)
            {
                // No data arrived within the timeout window. This is expected if the loopback wire is not connected.
                bytesRead = 0;
            }

            if (bytesRead > 0)
            {
                // Decode only the bytes actually received, not the whole buffer.
                string rxString = Encoding.ASCII.GetString(rxData, 0, bytesRead);
                Console.WriteLine($"Received: {rxString}");
            }
            else
            {
                Console.WriteLine("No data received");
            }
        }
        catch (Exception ex)
        {
            // Catches port-not-found, access-denied, and other fatal errors.
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            // Always close the port to release the OS handle, even if an exception was thrown during the test.
            if (ser != null && ser.IsOpen)
            {
                ser.Close();
                Console.WriteLine("Serial port closed");
            }
        }

        // Keep the console window open until the user presses Ctrl+C.
        // This is particularly important when the exe is launched by double-clicking in Windows Explorer rather than from a terminal.
        Console.WriteLine("\nPress Ctrl+C to exit...");
        exitEvent.Wait();
    }
}