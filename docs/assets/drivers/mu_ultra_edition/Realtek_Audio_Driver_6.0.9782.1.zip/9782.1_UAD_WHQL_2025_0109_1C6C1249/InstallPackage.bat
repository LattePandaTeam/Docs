
@echo pnputil -a "%~dp0Realtek\ExtRtk_9782.1\HDX_WeibuExt_THX.inf"
pnputil -a "%~dp0Realtek\ExtRtk_9782.1\HDX_WeibuExt_THX.inf"

@echo pnputil -a "%~dp0Realtek\Codec_9782.1\HDXSSTWeibu.inf" /install
pnputil -a "%~dp0Realtek\Codec_9782.1\HDXSSTWeibu.inf" /install

@echo pnputil -a "%~dp0Realtek\RealtekAPO_12_1505\RealtekAPO.inf" /install
pnputil -a "%~dp0Realtek\RealtekAPO_12_1505\RealtekAPO.inf" /install

@echo pnputil -a "%~dp0Realtek\RealtekAPO_13_1505\RealtekAPO.inf" /install
pnputil -a "%~dp0Realtek\RealtekAPO_13_1505\RealtekAPO.inf" /install

@echo pnputil -a "%~dp0Realtek\RealtekASIO_13\RealtekASIO.inf" /install
pnputil -a "%~dp0Realtek\RealtekASIO_13\RealtekASIO.inf" /install

@echo pnputil -a "%~dp0Realtek\RealtekHSA_354\RealtekHSA.inf" /install
pnputil -a "%~dp0Realtek\RealtekHSA_354\RealtekHSA.inf" /install

@echo pnputil -a "%~dp0Realtek\RealtekService_819\RealtekService.inf" /install
pnputil -a "%~dp0Realtek\RealtekService_819\RealtekService.inf" /install

@echo Done
pause
