@echo off
REM Install Goodix Touch Panel driver v1.3.2.0
REM Right-click this script and select "Run as administrator".

cd /d "%~dp0"

REM Check for administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Please run this script as Administrator.
    echo.
    pause
    exit /b 1
)

REM Add the driver package to the driver store and install it on matching devices
pnputil /add-driver "%~dp0goodixtouchdriver.inf" /install

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Driver installation failed.
    echo.
    pause
    exit /b 1
)

echo.
echo Driver installed successfully.
echo.
pause
exit /b 0
