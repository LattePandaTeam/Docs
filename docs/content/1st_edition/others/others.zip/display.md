## Connecting Display and Getting Touch

**To be updated...**

#### Display - 7 inch 1024 x 600 IPS screen 



*Note:Please connect it with LattePanda BEFORE power-on. And make sure the Golden Finger face the right side. *
The contacts on FPC are so compact and in order. Please be careful that any dislocation connection may cause the LattePanda short circuit and the IPS display abnormal like ghosting or flicker.

1. Lift up the actuator. Use thumb or index finger might be easier.
2. Insert display FPC in.

**Place Golden Finger side down!**
![img](http://www.lattepanda.com/wp-content/uploads/2016/05/6W4A0102.jpg)

**Note: The FPC must be fully inserted in the connector. If not fully inserted, the actuator will not close properly. Should this be the case, lift up the actuator and repeat the process (starting with Step 1 above)**

3. Rotate down the actuator until firmly closed.
4. Insert the FPC of touch panel in

Same as the display. Place the Golden Finger side down too.



#### Touch - I2C connection



#### 10 inch is coming

