## Gadgets create possibility

**To be updated...**



#### heat controlling

Fan 

Heat sinks