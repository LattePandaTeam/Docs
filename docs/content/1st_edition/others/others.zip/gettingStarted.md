To get started the development based on LattePanda, we need know several basic blocks including Power, Internet connection, display, settings and accessories, which bring more fun for your LattePanda.

Here's a list of all the contents in this section:

1. [Power on your device](../power_on.md)
2. Connecting to Internet!
3. Display and system setting
4. Expansibilities and other features

