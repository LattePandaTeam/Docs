# 1

## 2

### 3

#### 4

##### 5

6666

[link](http://doc.mak12.com/content/OS/Win10HomeAndLTSB/#windows-10-home)

![66666](https://i.imgur.com/PgC9KLb.gif)

